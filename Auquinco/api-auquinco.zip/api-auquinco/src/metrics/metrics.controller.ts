import { Controller, Get, Query } from '@nestjs/common';
import { SsrAuquincoService } from './metrics.service';
import { DateRangeDto } from './models/dto/date-range.dto';

@Controller('')
export class SsrAuquincoController {
  constructor(private readonly service: SsrAuquincoService) {}

  @Get('snapshot')
  getSnapshot() {
    return this.service.getSnapshot();
  }

  @Get('totalizador')
  getTotalizador(@Query() dto: DateRangeDto) {
    return this.service.getTotalizador(dto);
  }

  @Get('horometro')
  getHorometro(@Query() dto: DateRangeDto) {
    return this.service.getHorometro(dto);
  }

  @Get('nivel')
  getNivel(@Query() dto: DateRangeDto) {
    return this.service.getNivel(dto);
  }

  @Get('caudal')
  getCaudal(@Query() dto: DateRangeDto) {
    return this.service.getCaudal(dto);
  }

  @Get('kwh')
  getKwh(@Query() dto: DateRangeDto) {
    return this.service.getKwh(dto);
  }

  @Get('voltaje')
  getVoltaje(@Query() dto: DateRangeDto) {
    return this.service.getVoltaje(dto);
  }

  @Get('corriente')
  getCorriente(@Query() dto: DateRangeDto) {
    return this.service.getCorriente(dto);
  }

  @Get('presion')
  getPresion(@Query() dto: DateRangeDto) {
    return this.service.getPresion(dto);
  }

  @Get('voltaje-neutro')
  getVoltajeNeutro(@Query() dto: DateRangeDto) {
    return this.service.getVoltajeNeutro(dto);
  }
}
