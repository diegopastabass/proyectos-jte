import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Raw } from 'typeorm';
import { Telemetria } from './models/metrics.entity';
import { DateRangeDto } from './models/dto/date-range.dto';
import { MetricSnapshot, Metric } from './models/types';

interface DailyQueryResult {
  day: Date;
  daily_value: number;
}

@Injectable()
export class SsrAuquincoService {
  constructor(
    @InjectRepository(Telemetria)
    private repo: Repository<Telemetria>,
  ) {}

  private normalizeDateRange(
    dto: DateRangeDto,
  ): { start: Date; end: Date } | null {
    if (!dto.start || !dto.end) return null;

    const startDate = new Date(`${dto.start}T00:00:00Z`);
    const nextDay = new Date(dto.end);
    nextDay.setDate(nextDay.getDate() + 1);
    const endDate = new Date(`${nextDay.toISOString().slice(0, 10)}T00:00:00Z`);

    return { start: startDate, end: endDate };
  }

  // Snapshot
  async getSnapshot(): Promise<{
    snapshot: MetricSnapshot;
    tiempo_vaciado: number;
    tiempo_vaciado_formatted: string;
  }> {
    const results = await this.repo.query(`
    SELECT t.mt_name, t.mt_value, t.mt_time_2
    FROM ssr_auquinco t
    INNER JOIN (
      SELECT mt_name, MAX(mt_time_2) AS last_time
      FROM ssr_auquinco
      GROUP BY mt_name
    ) latest
    ON t.mt_name = latest.mt_name AND t.mt_time_2 = latest.last_time
  `);

    const prefix = 'SSR_AUQUINCO--slave.';

    const snapshot: MetricSnapshot = results.reduce(
      (acc: MetricSnapshot, row: any) => {
        const key = row.mt_name.replace(prefix, '');
        let value = Number(row.mt_value);

        if (key === 'automatico') {
          value = 1;
        }

        acc[key] = {
          value,
          time: new Date(row.mt_time_2).toISOString(),
        };
        return acc;
      },
      {},
    );

    const calcularTiempoVaciado = async (nombreEstanque: string) => {
      const mediciones = await this.repo.find({
        where: { mt_name: nombreEstanque },
        order: { mt_time_2: 'DESC' },
        take: 2,
      });

      if (mediciones.length < 2) {
        return { tiempo: 0, formatted: 'Llenando...' };
      }

      const [actual, anterior] = mediciones;
      const nivel_actual = Number(actual.mt_value);
      const nivel_anterior = Number(anterior.mt_value);

      const t_actual = actual.mt_time_2.getTime() / 1000;
      const t_anterior = anterior.mt_time_2.getTime() / 1000;

      if (!(nivel_actual < nivel_anterior && t_actual > t_anterior)) {
        return { tiempo: 0, formatted: 'Llenando...' };
      }

      const tasa_vaciado =
        (nivel_anterior - nivel_actual) / (t_actual - t_anterior);
      const tiempo = Math.round(nivel_actual / tasa_vaciado);

      const h = Math.floor(tiempo / 3600);
      const m = Math.floor((tiempo % 3600) / 60);
      const s = tiempo % 60;

      const formatted = `${h.toString().padStart(2, '0')} h ${m
        .toString()
        .padStart(2, '0')} m ${s.toString().padStart(2, '0')} s`;

      return { tiempo, formatted };
    };

    const estanque = await calcularTiempoVaciado(
      'SSR_AUQUINCO--slave.estanque',
    );

    return {
      snapshot,
      tiempo_vaciado: estanque.tiempo,
      tiempo_vaciado_formatted: estanque.formatted,
    };
  }

  // Daily Metrics
  private async calculateAndCacheDaily(
    metricName: string,
    start: string,
    end: string,
  ): Promise<Metric[]> {
    const cached = await this.repo.query(
      `SELECT mt_day, mt_value FROM ssr_auquinco_daily_metrics WHERE mt_name = $1 AND mt_day BETWEEN $2 AND $3`,
      [metricName, start, end],
    );

    const metricsMap = new Map<string, number>();
    cached.forEach((row: any) => {
      const dateStr =
        typeof row.mt_day === 'string'
          ? row.mt_day
          : row.mt_day.toISOString().split('T')[0];
      metricsMap.set(dateStr, Number(row.mt_value));
    });

    const missingDates: string[] = [];
    let currentDate = new Date(`${start}T00:00:00Z`);
    const endDate = new Date(`${end}T00:00:00Z`);
    const todayStr = new Date().toISOString().split('T')[0];

    while (currentDate <= endDate) {
      const dateStr = currentDate.toISOString().split('T')[0];
      if (!metricsMap.has(dateStr) || dateStr === todayStr) {
        missingDates.push(dateStr);
      }
      currentDate.setDate(currentDate.getDate() + 1);
    }

    if (missingDates.length > 0) {
      const calculated = await this.repo.query(
        `
        WITH bounds AS (
          SELECT mt_time_2::DATE AS day, MIN(mt_time_2) AS first_ts, MAX(mt_time_2) AS last_ts
          FROM ssr_auquinco
          WHERE mt_name = $1 AND mt_time_2::DATE = ANY($2::DATE[])
          GROUP BY mt_time_2::DATE
        )
        SELECT b.day,
          (MAX(CAST(s_last.mt_value AS NUMERIC(30,6))) - MIN(CAST(s_first.mt_value AS NUMERIC(30,6)))) AS daily_value
        FROM bounds b
        LEFT JOIN ssr_auquinco s_first
          ON s_first.mt_name = $1 AND s_first.mt_time_2 = b.first_ts
        LEFT JOIN ssr_auquinco s_last
          ON s_last.mt_name = $1 AND s_last.mt_time_2 = b.last_ts
        GROUP BY b.day
        `,
        [metricName, missingDates],
      );

      for (const row of calculated) {
        const dateStr =
          typeof row.day === 'string'
            ? row.day
            : row.day.toISOString().split('T')[0];
        const val = Number(row.daily_value || 0);

        await this.repo.query(
          `INSERT INTO ssr_auquinco_daily_metrics (mt_name, mt_day, mt_value) 
           VALUES ($1, $2, $3) 
           ON CONFLICT (mt_name, mt_day) DO UPDATE SET mt_value = EXCLUDED.mt_value`,
          [metricName, dateStr, val],
        );

        metricsMap.set(dateStr, val);
      }
    }

    const results: Metric[] = [];
    currentDate = new Date(`${start}T00:00:00Z`);

    while (currentDate <= endDate) {
      const dateStr = currentDate.toISOString().split('T')[0];
      if (metricsMap.has(dateStr)) {
        results.push({ time: dateStr, value: metricsMap.get(dateStr)! });
      }
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return results;
  }

  // Totalizador
  async getTotalizador(dto: DateRangeDto): Promise<Metric[]> {
    if (!dto || !dto.start || !dto.end)
      throw new Error('Se requiere rango de fechas válido.');
    return this.calculateAndCacheDaily(
      'SSR_AUQUINCO--slave.totalizador',
      dto.start,
      dto.end,
    );
  }

  // Horometro
  async getHorometro(dto: DateRangeDto): Promise<Metric[]> {
    if (!dto || !dto.start || !dto.end)
      throw new Error('Se requiere rango de fechas válido.');
    return this.calculateAndCacheDaily(
      'SSR_AUQUINCO--slave.horometro',
      dto.start,
      dto.end,
    );
  }

  async getKwh(
    dto: DateRangeDto,
  ): Promise<{ KW1: Metric[]; KW2: Metric[]; KW3: Metric[] }> {
    if (!dto || !dto.start || !dto.end)
      throw new Error('Se requiere rango de fechas válido.');

    const [KW1, KW2, KW3] = await Promise.all([
      this.calculateAndCacheDaily(
        'SSR_AUQUINCO--slave.KW1',
        dto.start,
        dto.end,
      ),
      this.calculateAndCacheDaily(
        'SSR_AUQUINCO--slave.KW2',
        dto.start,
        dto.end,
      ),
      this.calculateAndCacheDaily(
        'SSR_AUQUINCO--slave.KW3',
        dto.start,
        dto.end,
      ),
    ]);

    return { KW1, KW2, KW3 };
  }

  // Nivel
  async getNivel(dto: DateRangeDto): Promise<Metric[]> {
    const range = this.normalizeDateRange(dto);

    if (range) {
      const { start, end } = range;
      const results = await this.repo.find({
        where: {
          mt_name: 'SSR_AUQUINCO--slave.estanque',
          mt_time_2: Raw((alias) => `${alias} >= :start AND ${alias} < :end`, {
            start,
            end,
          }),
        },
        order: { mt_time_2: 'ASC' },
      });

      return results.map((row) => ({
        time: row.mt_time_2.toISOString(),
        value: Number(row.mt_value),
      }));
    }

    // Ultimas 6 horas
    const start = new Date(Date.now() - 6 * 60 * 60 * 1000);
    const results = await this.repo.find({
      where: {
        mt_name: 'SSR_AUQUINCO--slave.estanque',
        mt_time_2: Raw((alias) => `${alias} >= :start`, { start }),
      },
      order: { mt_time_2: 'ASC' },
    });

    return results.map((row) => ({
      time: row.mt_time_2.toISOString(),
      value: Number(row.mt_value),
    }));
  }

  // Caudal
  async getCaudal(dto: DateRangeDto): Promise<Metric[]> {
    const range = this.normalizeDateRange(dto);

    if (!range) {
      // Ultimas 6 horas
      const start = new Date(Date.now() - 6 * 60 * 60 * 1000);
      const results = await this.repo.find({
        where: {
          mt_name: 'SSR_AUQUINCO--slave.caudal',
          mt_time_2: Raw((alias) => `${alias} >= :start`, { start }),
        },
        order: { mt_time_2: 'ASC' },
      });

      return results.map((row) => ({
        time: row.mt_time_2.toISOString(),
        value: Number(row.mt_value),
      }));
    }

    const { start, end } = range;

    const results = await this.repo.find({
      where: {
        mt_name: 'SSR_AUQUINCO--slave.caudal',
        mt_time_2: Raw((alias) => `${alias} >= :start AND ${alias} < :end`, {
          start,
          end,
        }),
      },
      order: { mt_time_2: 'ASC' },
    });

    return results.map((row) => ({
      time: row.mt_time_2.toISOString(),
      value: Number(row.mt_value),
    }));
  }

  // Corriente
  async getCorriente(
    dto: DateRangeDto,
  ): Promise<{ i1: Metric[]; i2: Metric[]; i3: Metric[] }> {
    const range = this.normalizeDateRange(dto);

    const fetchVariable = async (variable: string) => {
      const mtName = `SSR_AUQUINCO--slave.${variable}`;
      if (!range) {
        const start = new Date(Date.now() - 6 * 60 * 60 * 1000);
        const results = await this.repo.find({
          where: {
            mt_name: mtName,
            mt_time_2: Raw((alias) => `${alias} >= :start`, { start }),
          },
          order: { mt_time_2: 'ASC' },
        });

        return results.map((row) => ({
          time: row.mt_time_2.toISOString(),
          value: Number(row.mt_value),
        }));
      }

      const { start, end } = range;

      const results = await this.repo.find({
        where: {
          mt_name: mtName,
          mt_time_2: Raw((alias) => `${alias} >= :start AND ${alias} < :end`, {
            start,
            end,
          }),
        },
        order: { mt_time_2: 'ASC' },
      });

      return results.map((row) => ({
        time: row.mt_time_2.toISOString(),
        value: Number(row.mt_value),
      }));
    };

    const [i1, i2, i3] = await Promise.all([
      fetchVariable('I1'),
      fetchVariable('I2'),
      fetchVariable('I3'),
    ]);

    return { i1, i2, i3 };
  }

  // Voltaje
  async getVoltaje(
    dto: DateRangeDto,
  ): Promise<{ L1L2: Metric[]; L2L3: Metric[]; L3L1: Metric[] }> {
    const range = this.normalizeDateRange(dto);

    const fetchVariable = async (variable: string) => {
      const mtName = `SSR_AUQUINCO--slave.${variable}`;
      if (!range) {
        const start = new Date(Date.now() - 6 * 60 * 60 * 1000);
        const results = await this.repo.find({
          where: {
            mt_name: mtName,
            mt_time_2: Raw((alias) => `${alias} >= :start`, { start }),
          },
          order: { mt_time_2: 'ASC' },
        });

        return results.map((row) => ({
          time: row.mt_time_2.toISOString(),
          value: Number(row.mt_value),
        }));
      }

      const { start, end } = range;

      const results = await this.repo.find({
        where: {
          mt_name: mtName,
          mt_time_2: Raw((alias) => `${alias} >= :start AND ${alias} < :end`, {
            start,
            end,
          }),
        },
        order: { mt_time_2: 'ASC' },
      });

      return results.map((row) => ({
        time: row.mt_time_2.toISOString(),
        value: Number(row.mt_value),
      }));
    };

    const [L1L2, L2L3, L3L1] = await Promise.all([
      fetchVariable('L1L2'),
      fetchVariable('L2L3'),
      fetchVariable('L3L1'),
    ]);

    return { L1L2, L2L3, L3L1 };
  }

  // Voltaje Neutro
  async getVoltajeNeutro(
    dto: DateRangeDto,
  ): Promise<{ L1N: Metric[]; L2N: Metric[]; L3N: Metric[] }> {
    const range = this.normalizeDateRange(dto);

    const fetchVariable = async (variable: string) => {
      const mtName = `SSR_AUQUINCO--slave.${variable}`;
      if (!range) {
        const start = new Date(Date.now() - 6 * 60 * 60 * 1000);
        const results = await this.repo.find({
          where: {
            mt_name: mtName,
            mt_time_2: Raw((alias) => `${alias} >= :start`, { start }),
          },
          order: { mt_time_2: 'ASC' },
        });

        return results.map((row) => ({
          time: row.mt_time_2.toISOString(),
          value: Number(row.mt_value),
        }));
      }

      const { start, end } = range;

      const results = await this.repo.find({
        where: {
          mt_name: mtName,
          mt_time_2: Raw((alias) => `${alias} >= :start AND ${alias} < :end`, {
            start,
            end,
          }),
        },
        order: { mt_time_2: 'ASC' },
      });

      return results.map((row) => ({
        time: row.mt_time_2.toISOString(),
        value: Number(row.mt_value),
      }));
    };

    const [L1N, L2N, L3N] = await Promise.all([
      fetchVariable('L1N'),
      fetchVariable('L2N'),
      fetchVariable('L3N'),
    ]);

    return { L1N, L2N, L3N };
  }

  // Presion
  async getPresion(dto: DateRangeDto): Promise<Metric[]> {
    const range = this.normalizeDateRange(dto);
    if (!range) {
      const start = new Date(Date.now() - 6 * 60 * 60 * 1000);
      const results = await this.repo.find({
        where: {
          mt_name: 'SSR_AUQUINCO--slave.presion',
          mt_time_2: Raw((alias) => `${alias} >= :start`, { start }),
        },
        order: { mt_time_2: 'ASC' },
      });

      return results.map((row) => ({
        time: row.mt_time_2.toISOString(),
        value: Number(row.mt_value),
      }));
    }

    const { start, end } = range;

    const results = await this.repo.find({
      where: {
        mt_name: 'SSR_AUQUINCO--slave.presion',
        mt_time_2: Raw((alias) => `${alias} >= :start AND ${alias} < :end`, {
          start,
          end,
        }),
      },
      order: { mt_time_2: 'ASC' },
    });

    return results.map((row) => ({
      time: row.mt_time_2.toISOString(),
      value: Number(row.mt_value),
    }));
  }
}
