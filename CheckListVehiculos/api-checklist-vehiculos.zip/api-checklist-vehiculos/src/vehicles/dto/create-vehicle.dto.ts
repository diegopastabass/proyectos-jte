import { IsString, IsInt, IsOptional, IsDateString } from 'class-validator';

export class CreateVehicleDto {
  @IsString()
  model: string;

  @IsString()
  patente: string;

  @IsOptional()
  @IsInt()
  kilometraje?: number;

  @IsOptional()
  @IsDateString()
  fecha_venc_revision_tecnica?: string;

  @IsOptional()
  @IsDateString()
  fecha_venc_circulacion?: string;
}
