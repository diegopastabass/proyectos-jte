import {
  Controller,
  Post,
  UseGuards,
  UseInterceptors,
  UploadedFile,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { RecognitionService } from './recognition.service.js';
import { JwtAuthGuard } from '../auth/jwt-auth.guard.js';

@UseGuards(JwtAuthGuard)
@Controller('recognition')
export class RecognitionController {
  private readonly logger = new Logger(RecognitionController.name);

  constructor(private readonly recognitionService: RecognitionService) {}

  @Post('detect')
  @UseInterceptors(FileInterceptor('image'))
  async detect(@UploadedFile() file: Express.Multer.File) {
    if (!file) {
      throw new BadRequestException('Debe enviar una imagen con el campo "image"');
    }

    this.logger.log(`Imagen recibida: ${file.originalname} (${file.size} bytes)`);
    return this.recognitionService.detectAndVerify(file.buffer);
  }
}
